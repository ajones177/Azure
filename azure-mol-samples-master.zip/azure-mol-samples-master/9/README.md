This samples scripts create either a zone-redundant virtual machine scale set or a redundant Web App.

For both, autoscale rules are configured that allow the resource to automatically scale up or down as CPU load changes.